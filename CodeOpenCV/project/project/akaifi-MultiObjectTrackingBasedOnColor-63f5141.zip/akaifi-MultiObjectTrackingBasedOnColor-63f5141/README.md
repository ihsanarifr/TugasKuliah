# MultiObjectTrackingBasedOnColor
###Track multiple objects based on their color using OpenCV
---

####In order to run the application, you need to do the follwing steps:

1 - Proper installation of OpenCV V2.4.9

2- Make a new project in Visual Sudio including OpenCV path in your solution.

3- Add the attached files and build the project.

Note: make sure you have a web cam in your PC or Laptop.


Thank You,

Ahmad Kaifi,     
Hassan Althobaiti,     
Zubir Rentiya


 [![Throughput Graph](https://graphs.waffle.io/akaifi/MultiObjectTrackingBasedOnColor/throughput.svg)](https://waffle.io/akaifi/MultiObjectTrackingBasedOnColor/metrics) 
