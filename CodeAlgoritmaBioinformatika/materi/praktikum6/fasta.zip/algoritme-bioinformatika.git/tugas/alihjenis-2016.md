### Tugas Algoritme Bioinformatika

Data yang digunakan adalah file [flu_A.fasta](http://code.cs.ipb.ac.id/abrari/algoritme-bioinformatika/blob/master/data/flu_A.fasta).

1. Dari file FASTA tersebut, pilih salah satu baris sekuensnya (misalnya sekuens baris ke-11). Pastikan panjangnya 70 karakter. Sebut sekuens ini sebagai **sekuens 1**. Contohnya baris ke-11:

        ATAACAGACACTATCAAGAGTTGGAGGAACAACATAATGAGAACTCAAGAGTCTGAATGTGCATGTGTAA

    Pilihlah baris secara acak, dan jangan ikut-ikutan teman Anda.

2. Lakukan modifikasi terhadap sekuens 1, misalnya dikurangi beberapa karakter, disisipi beberapa karakter (A, T, G, C), atau diulang karakter-karakternya. Sebut sekuens ini sebagai **sekuens 2**.

    Lakukan modifikasi secara *acak*. Jika hasil modifikasi acak Anda sama dengan teman Anda sudah bisa dipastikan bahwa Anda mencontek.

3. Lakukan penjajaran dengan Global Alignment antara **sekuens 1** dan **sekuens 2**. Algoritme penjajarannya sudah diimplementasikan di script [pairwise_global.py](http://code.cs.ipb.ac.id/abrari/algoritme-bioinformatika/blob/master/pairwise_global.py), Anda tinggal menggunakannya. 

    Tapi sebelumnya pastikan Anda sudah menginstal library Python `numpy` di komputer.

4. Lakukan penjajaran dengan data yang sama, tapi kali ini dengan Local Alignment. Algoritmenya juga sudah diimplementasikan di script [pairwise_local.py](http://code.cs.ipb.ac.id/abrari/algoritme-bioinformatika/blob/master/pairwise_local.py).

5. Laporkan proses dan hasilnya dalam sebuah file PDF yang dikumpulkan di LMS.

