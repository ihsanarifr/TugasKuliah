package Tugas3;

public interface Kerja {
    public void kerjaPersegi(int s);
    public void kerjaKubus(int r);
}
