package Tugas3;

public interface Administrasi {
    public void hitungGaji(int anak,int lama);
    public void hitungPotongan(int cuti);
}
